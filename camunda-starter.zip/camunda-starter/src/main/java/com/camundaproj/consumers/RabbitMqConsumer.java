package com.camundaproj.consumers;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

@Component
public class RabbitMqConsumer {
    @PostConstruct
    public void onInit(){
        System.out.println("Message 11111");
    }

}
