package com.camundaproj.consumers;

import javax.annotation.PostConstruct;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class RMQConsumer {
    
    @PostConstruct
    public void onInit(){
        System.out.println("Message 11111");
    }

    @RabbitListener(queues = { "listner1" })
    public void receive(@Payload String fileBody) {
        System.out.println("Message " + fileBody);

    }

}
