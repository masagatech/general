package com.camundaproj.camundastarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamundaStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamundaStarterApplication.class, args);
	}

}
