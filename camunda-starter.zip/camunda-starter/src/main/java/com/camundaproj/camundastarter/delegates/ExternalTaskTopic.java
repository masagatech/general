package com.camundaproj.camundastarter.delegates;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.springframework.stereotype.Component;

@Component
//@ExternalTaskSubscription("eligibilityCheck")
public class ExternalTaskTopic implements ExternalTaskHandler {

    @Override
    public void execute(ExternalTask arg0, ExternalTaskService arg1) {
       // arg1.handleFailure(arg0.getActivityId(), "errorMessage", "errorDetails", 1, 1000 * 4);
       arg1.complete(arg0); 
    }

}
