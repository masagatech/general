package com.camundaproj.camundastarter.delegates;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;

public class MessageNotify1 implements ExecutionListener {

    @Override
    public void notify(DelegateExecution arg0) throws Exception {
        System.out.println(arg0);
        
    }
        
}
