package com.camundaproj.camundastarter.delegates;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.camunda.bpm.engine.RuntimeService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import camundajar.impl.com.google.gson.Gson; 

@Component
public class Consumer {

    @Autowired
    RuntimeService runtimeService;

    @PostConstruct
    public void onInit() {
        System.out.println("Message 11111");
    }

    @RabbitListener(queues = { "listner1" })
    public void receive(@Payload String fileBody) throws InterruptedException {

        Gson g = new Gson();

        // Type type = new TypeToken<Map<String, Object>>() {
        // }.getType();
        Map<String, Object> map = new HashMap<String, Object>();
        map = (Map<String, Object>) g.fromJson(fileBody, map.getClass());
        System.out.println("Message " + fileBody);
        Thread.sleep(200);
        String constsJson = map.get("const").toString();
       
        Map<String, Object> mapConsts = g.fromJson(constsJson, Map.class);

        runtimeService.createMessageCorrelation(mapConsts.get("responseQueue").toString())
                .processInstanceBusinessKey(map.get("businessKey").toString())
                .correlate();

    }
}
