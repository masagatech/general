package com.camundaproj.camundastarter.delegates;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate; 

public class Delegate1 implements JavaDelegate {

    

    @Override
    public void execute(DelegateExecution arg0) throws Exception {
        System.out.print(arg0);
     

    }

}
