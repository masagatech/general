package com.camundaproj.camundastarter.delegates;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import camundajar.impl.com.google.gson.Gson;

/**
 * Queque
 */
@Component
public class QuequeDelegate implements JavaDelegate {

    @PostConstruct
    public void onInit() {
        System.out.println("Message 11111");
    }

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Override
    public void execute(DelegateExecution execution) throws Exception {

        Gson g = new Gson();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("const", execution.getVariable("local-const").toString());
        map.put("businessKey", execution.getBusinessKey());

        rabbitTemplate.convertAndSend("", "listner1", g.toJson(map).toString());
    }

}