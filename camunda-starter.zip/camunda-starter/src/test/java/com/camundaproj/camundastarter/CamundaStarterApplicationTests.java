package com.camundaproj.camundastarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamundaStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
